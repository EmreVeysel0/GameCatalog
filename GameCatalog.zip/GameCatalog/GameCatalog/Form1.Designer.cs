﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace GameCatalog
{
    public partial class Form1 : Form
    {
        private string connectionString = "DESKTOP-M71SG0B\\SQLEXPRESS;Database=GameCatalog;Integrated Security=true;TrustServerCertificate=true;Encrypt=false;";

        

        private void CreateDatabaseIfNeeded()
        {
            try
            {
              
                string masterConnection = "DESKTOP-M71SG0B\\SQLEXPRESS;Database=master;Integrated Security=true;TrustServerCertificate=true;Encrypt=false;";

                using (SqlConnection conn = new SqlConnection(masterConnection))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'GameCatalog') CREATE DATABASE GameCatalog", conn);
                    cmd.ExecuteNonQuery();
                }

                
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string createTable = @"
                        IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Games')
                        BEGIN
                            CREATE TABLE Games (
                                GameID int IDENTITY(1,1) PRIMARY KEY,
                                Title nvarchar(100) NOT NULL,
                                Genre nvarchar(50),
                                ReleaseYear int,
                                Price decimal(10,2)
                            )
                            
                            INSERT INTO Games (Title, Genre, ReleaseYear, Price) VALUES
                            ('FIFA 24', 'Sports', 2023, 59.99),
                            ('Call of Duty', 'Action', 2023, 69.99),
                            ('Minecraft', 'Sandbox', 2011, 26.95)
                        END";
                    SqlCommand cmd = new SqlCommand(createTable, conn);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Database and table created successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Setup error: " + ex.Message);
            }
        }

        private void LoadGames()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT GameID, Title, Genre, ReleaseYear, Price FROM Games";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvGames.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtTitle.Text))
                {
                    MessageBox.Show("Please enter a title!");
                    return;
                }

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Games (Title, Genre, ReleaseYear, Price) VALUES (@title, @genre, @year, @price)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@title", txtTitle.Text);
                    cmd.Parameters.AddWithValue("@genre", txtGenre.Text);
                    cmd.Parameters.AddWithValue("@year", string.IsNullOrWhiteSpace(txtYear.Text) ? 0 : int.Parse(txtYear.Text));
                    cmd.Parameters.AddWithValue("@price", string.IsNullOrWhiteSpace(txtPrice.Text) ? 0 : decimal.Parse(txtPrice.Text));

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Game added successfully!");
                LoadGames();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Add error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvGames.SelectedRows.Count > 0)
                {
                    int gameId = (int)dgvGames.SelectedRows[0].Cells["GameID"].Value;

                    DialogResult result = MessageBox.Show("Are you sure you want to delete this game?", "Confirm Delete", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            string query = "DELETE FROM Games WHERE GameID = @id";
                            SqlCommand cmd = new SqlCommand(query, conn);
                            cmd.Parameters.AddWithValue("@id", gameId);

                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("Game deleted successfully!");
                        LoadGames();
                    }
                }
                else
                {
                    MessageBox.Show("Please select a game to delete!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete error: " + ex.Message);
            }
        }

        private void ClearFields()
        {
            txtTitle.Clear();
            txtGenre.Clear();
            txtYear.Clear();
            txtPrice.Clear();
        }
    }
}