namespace GameCatalog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            dgvGames = new DataGridView();
            Title = new Label();
            Genre = new Label();
            Year = new Label();
            Price = new Label();
            btnAdd = new Button();
            txtTitle = new TextBox();
            txtGenre = new TextBox();
            txtYear = new TextBox();
            txtPrice = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvGames).BeginInit();
            SuspendLayout();
            
            dgvGames.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGames.Location = new Point(678, 102);
            dgvGames.Name = "dgvGames";
            dgvGames.RowHeadersWidth = 51;
            dgvGames.Size = new Size(300, 227);
            dgvGames.TabIndex = 0;
            dgvGames.CellContentClick += dgvGames_CellContentClick;
             
            Title.AutoSize = true;
            Title.Location = new Point(114, 102);
            Title.Name = "Title";
            Title.Size = new Size(29, 15);
            Title.TabIndex = 1;
            Title.Text = "Title";
            Title.Click += Title_Click;
           
            Genre.AutoSize = true;
            Genre.Location = new Point(114, 168);
            Genre.Name = "Genre";
            Genre.Size = new Size(29, 15);
            Genre.TabIndex = 2;
            Genre.Text = "Year";
          
            Year.AutoSize = true;
            Year.Location = new Point(114, 240);
            Year.Name = "Year";
            Year.Size = new Size(38, 15);
            Year.TabIndex = 3;
            Year.Text = "Genre";
            
            Price.AutoSize = true;
            Price.Location = new Point(114, 309);
            Price.Name = "Price";
            Price.Size = new Size(33, 15);
            Price.TabIndex = 4;
            Price.Text = "Price";
            
            btnAdd.Location = new Point(746, 387);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(145, 69);
            btnAdd.TabIndex = 5;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
           
            txtTitle.Location = new Point(241, 95);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(125, 23);
            txtTitle.TabIndex = 7;
            
            txtGenre.Location = new Point(241, 165);
            txtGenre.Name = "txtGenre";
            txtGenre.Size = new Size(125, 23);
            txtGenre.TabIndex = 8;
            
            txtYear.Location = new Point(241, 237);
            txtYear.Name = "txtYear";
            txtYear.Size = new Size(125, 23);
            txtYear.TabIndex = 9;
           
            txtPrice.Location = new Point(241, 306);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(125, 23);
            txtPrice.TabIndex = 10;
           
            ClientSize = new Size(1091, 537);
            Controls.Add(txtPrice);
            Controls.Add(txtYear);
            Controls.Add(txtGenre);
            Controls.Add(txtTitle);
            Controls.Add(btnAdd);
            Controls.Add(Price);
            Controls.Add(Year);
            Controls.Add(Genre);
            Controls.Add(Title);
            Controls.Add(dgvGames);
            Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvGames).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private DataGridView dgvGames;
        private Label Title;
        private Label Genre;
        private Label Year;
        private Label Price;
        private Button btnAdd;
        private TextBox txtTitle;
        private TextBox txtGenre;
        private TextBox txtYear;
        private TextBox txtPrice;

        private void dgvGames_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Title_Click(object sender, EventArgs e)
        {

        }
    }
}
